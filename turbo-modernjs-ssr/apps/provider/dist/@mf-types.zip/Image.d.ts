export * from './compiled-types/src/components/Image';
export { default } from './compiled-types/src/components/Image';